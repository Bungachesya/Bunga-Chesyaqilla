<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\AlbumController;
use App\Http\Controllers\FotoController;
use App\Http\Controllers\KomentarController;
use App\Http\Controllers\LikeController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/home', function () {
    return view('home');
});

Route::get('/login', function () {
    return view('login');
});

Route::get('/daftar', function () {
    return view('daftar');
});

Route::get('/halamanutama', function () {
    return view('halamanutama');
});

Route::get('/album', function () {
    return view('album');
});

Route::get('/tambahalbum', function () {
    return view('tambahalbum');
});

Route::get('/foto', function () {
    return view('foto');
});

Route::get('/tambahfoto', function () {
    return view('tambahfoto');
});

Route::get('/komentar', function () {
    return view('komentar');
});

Route::get('/lihatkomentar', function () {
    return view('lihatkomentar');
});

Route::get('/login', [LoginController::class, 'tampil']);
Route::post('/halamanutama', [LoginController::class, 'login']);
Route::get('/logout', [LoginController::class,'logout']);

//routes registrasi controller
Route::get('/daftar', [RegisterController::class,'tampil']);
Route::post('/login', [RegisterController::class,'aksidaftar']);

//routes album controller
Route::get('/album', [AlbumController::class,'album']);
Route::post('/album', [AlbumController::class,'tambahAlbum']);

//routes foto controller
Route::get('/tambahfoto/{AlbumID}', [FotoController::class,'Foto']);
Route::post('/foto/{AlbumID}', [FotoController::class,'tambahFoto']);
Route::get('/foto/{AlbumID}', [FotoController::class,'lihatfoto']);
Route::get('/halamanutama', [FotoController::class,'lihatfoto1']);

//routes komentar controller
Route::get('/komentar/{FotoID}', [KomentarController::class,'tampilKomentar']);
Route::post('/lihatkomentar/{FotoID}', [KomentarController::class,'aksiTambahKomentar']);
Route::get('/lihatkomentar/{FotoID}', [KomentarController::class,'lihatKomentar']);

Route::get('/halamanutama/{FotoID}', [LikeController::class, 'lihatFoto']);
Route::post('/berilike/{FotoID}', [LikeController::class, 'like']);
