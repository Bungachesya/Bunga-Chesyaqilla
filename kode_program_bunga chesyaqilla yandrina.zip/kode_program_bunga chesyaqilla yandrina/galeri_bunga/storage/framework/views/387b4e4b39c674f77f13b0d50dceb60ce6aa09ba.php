<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foto - Gallery Photo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            height: 100vh;
            background-color: #ffccff;
        }

        header {
            background-color: #ff99cc;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .back-button {
            background-color: #cc3399;
            color: #fff;
            padding: 8px 16px; /* Mengubah padding */
            border-radius: 5px; /* Mengubah border-radius */
            text-decoration: none;
            transition: background-color 0.3s ease;
            font-family: 'Montserrat'; /* Menggunakan font Montserrat */
            font-weight: bold;
            font-size: 14px;
            display: flex; /* Menjadikan tampilan tombol flex */
            align-items: center; /* Posisikan ikon dan teks ke tengah tombol */
        }

        .back-button:hover {
            background: #00ffff;
        }

        .back-button i {
            margin-right: 5px; /* Spasi antara ikon dan teks */
        }

        nav {
            display: flex;
            align-items: center;
        }

        nav a {
            text-decoration: none;
            color: rgb(255, 255, 255);
            margin: 0 15px;
            font-weight: bold;
        }

        .foto-button:hover {
            background: #00ffff;
        }

        .foto-button {
            background: #cc3399;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s ease;
            text-decoration: none;
            font-family: 'Times New Roman', Times, serif; /* Menggunakan font Times New Roman */
        }

        .image-row {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            margin-top: 20px;
        }

        .image-container {
            text-align: center;
            width: calc(33.33% - 180px); /* Lebar box disesuaikan dengan jumlah kolom dan margin */
            margin-bottom: 20px;
            padding: 20px; /* Padding untuk isi box */
            border-radius: 10px; /* Sudut border box */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Shadow untuk efek 3D */
            position: relative; /* Menjadikan posisi relative untuk konten tambahan */
        }

        .image-container img {
            width: 90%; /* Lebar foto diatur agar selalu memenuhi box */
            border-radius: 10px; /* Sudut border foto */
            margin-bottom: 10px;
        }

        .image-container h3 {
            margin: 3px 0;
            color: #333;
            font-family: 'Protest Riot', sans-serif;
        }

        .image-container p {
            margin: 5px 0;
            color: #777;
            font-family: 'Georgia', serif;
            font-weight: normal;
        }

    </style>
</head>

<body>
    <header>
        <a href="/album" class="back-button"><i class="fas fa-arrow-left"></i> Kembali</a>
    </header>
    <br>
    <br>

    <center>
        <a href="/tambahfoto/<?php echo e($AlbumID); ?>" class="foto-button">Tambah Foto</a>
    </center>

    <div class="image-row">
        <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session()->get('Data Login')->UserID == $item->UserID && $item->AlbumID == $AlbumID): ?>
        <div class="image-container">
            <img src="<?php echo e($item->LokasiFile); ?>">
            <h3><?php echo e($item->JudulFoto); ?></h3>
            <p><?php echo e($item->DeskripsiFoto); ?></p>
            <p style="margin-bottom: 20px;"><?php echo e($item->TanggalUnggah); ?></p>
            <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&family=Protest+Riot&display=swap" rel="stylesheet">
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\galeri_bunga\resources\views/foto.blade.php ENDPATH**/ ?>