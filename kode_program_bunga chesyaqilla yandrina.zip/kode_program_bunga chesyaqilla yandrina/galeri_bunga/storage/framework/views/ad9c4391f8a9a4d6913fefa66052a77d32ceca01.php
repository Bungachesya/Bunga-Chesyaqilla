<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Album - Gallery Photo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #ffccff;
        }

        header {
            background-color: #ff99cc;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .add-album-form {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 400px;
            background: #ff99cc;
            border-radius: 10px;
            padding: 20px;
            box-sizing: border-box;
            text-align: center;
        }

        .add-album-form h3 {
            font-family: 'Times New Roman', Times, serif;
            font-size: 20px;
            margin-bottom: 20px;
        }

        .add-album-form label {
            display: block;
            text-align: left;
            font-family: 'Times New Roman', Times, serif;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .add-album-form input,
        .add-album-form textarea {
            width: 100%;
            margin-bottom: 20px;
            padding: 10px;
            box-sizing: border-box;
            font-family: 'Times New Roman', Times, serif;
            font-size: 14px;
        }

        .common-button {
            border: none;
            outline: none;
            height: 30px;
            font-size: 15px;
            border-radius: 20px;
            cursor: pointer;
        }

        .add-album-form input[type="submit"] {
            background: #59238F;
            color: #fff;
        }

        .back-button {
            background-color: #cc3399;
            color: #fff;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
            font-family: 'Montserrat';
            font-weight: bold;
            font-size: 14px;
            display: flex;
        }

        .back-button:hover {
            background: #00ffff;
        }

        .back-button i {
            margin-right: 5px; /* Spasi antara ikon dan teks */
        }

    </style>
</head>

<body>
    <header>
        <a href="/album" class="back-button"><i class="fas fa-arrow-left"></i> Kembali</a>
    </header>

    <div class="add-album-form">
        <h3>TAMBAH ALBUM</h3>
        <form action="/album" method="post">
<?php echo csrf_field(); ?>
            <label for="nama_album">Nama Album:</label>
            <input type="text" id="nama_album" name="NamaAlbum" required>

            <label for="deskripsi_album">Deskripsi Album:</label>
            <textarea id="deskripsi_album" name="Deskripsi" rows="4" required></textarea>

            <input type="submit" class="common-button" value="SUBMIT">
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\galeri_bunga\resources\views/tambahalbum.blade.php ENDPATH**/ ?>