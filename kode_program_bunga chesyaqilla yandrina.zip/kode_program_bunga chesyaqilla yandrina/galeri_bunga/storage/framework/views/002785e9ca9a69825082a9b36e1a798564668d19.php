<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Website Galeri Foto</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Font Awesome CSS -->

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
            height: 110vh;
            background-size: cover;
            background-image: url('asset/images/jls.jpg');
        }

        header {
            background-color: #ff99cc;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.5em;
            margin: 0;
            font-family: 'Pacifico';
        }

        nav {
            display: flex;
            align-items: center;
        }

        nav a {
            text-decoration: none;
            color: white;
            margin: 0 15px;
            font-weight: bold;
        }

        .logout-button {
            background-color: #cc3399;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-family: 'Cursive', sans-serif;
            transition: background-color 0.3s ease; /* Efek transisi */
        }

        .logout-button:hover {
            background-color: #00ffff; /* Ubah warna menjadi #00ffff saat hover */
        }

        main {
            padding: 20px;
            text-align: center;
        }

        .welcome-content {
            background-color: #ff99cc;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-family: 'Times New Roman', serif;
        }

        h1 {
            color: #333;
            font-family: monospace;
        }

        .image-row {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            margin-top: 20px;
        }

        .image-container {
            text-align: center;
            width: calc(33.33% - 100px); /* Lebar box disesuaikan dengan jumlah kolom dan margin */
            background-color: rgba(249, 249, 249, 0.2); /* Warna latar belakang box */
            padding: 20px; /* Padding untuk isi box */
            border-radius: 15px; /* Sudut border box */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Shadow untuk efek 3D */
            display: flex; /* Menggunakan flexbox */
            flex-direction: column; /* Menata elemen secara vertikal */
            align-items: center; /* Pusatkan elemen secara horizontal */
        }

        .image-container img {
            width: 90%; /* Lebar foto diatur agar selalu memenuhi box */
            border-radius: 10px; /* Sudut border foto */
            margin-bottom: 10px;
        }

        .image-container h3 {
            margin: 5px 0;
            color: #333;
            font-family: 'Arial', sans-serif;
        }

        .image-container p {
            color: #777;
            font-family: 'Georgia', serif;
            margin-bottom: 5px; /* Jarak antara deskripsi dan tanggal foto */
            font-weight: normal; /* Mengubah teks deskripsi foto menjadi tidak tebal */
        }

        .like-button, .comment-button, .view-comment-button {
            display: inline-block;
            padding: 5px 5px; /* Penyesuaian padding */
            background-color: #ff99cc;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s ease;
            margin-bottom: 10px; /* Menambahkan ruang antara tombol */
        }

        .like-button:hover, .comment-button:hover, .view-comment-button:hover {
            background-color: #f06292;
        }

        .like-count {
            padding: 4px 5px;
            font-size: 0.9em;
            margin-left: 2px;
        }

        .button-group {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }

    </style>
</head>

<body>
    <header>
        <h1 class="logo" style="color: white">Gallery Photo</h1>
        <nav>
            <a href="album" class="logout-button" style="background-color:#cc3399;">Koleksi saya</a>
            <a href="logout" class="logout-button">Log Out</a>
        </nav>
    </header>

    <main>
        <div class="welcome-content">
            <h1>Selamat Datang di Website Gallery Photo <?php echo e((Session()->get('Data Login')->Username)); ?></h1>
            <p>Temukan dan nikmati berbagai koleksi foto yang menarik di galeri kami.</p>
        </div>

        <h2>Foto Terbaru</h2>
        <div class="image-row">
            <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="image-container">
                <img src="<?php echo e($item->LokasiFile); ?>" class="brand_logo" alt="Foto 1">
                <h3><?php echo e($item->JudulFoto); ?></h3>
                <p><?php echo e($item->DeskripsiFoto); ?></p>
                <p><?php echo e($item->TanggalUnggah); ?></p>
                <div class="button-group">
                    <form action="/berilike/<?php echo e($item->FotoID); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <?php
                        $cek = \App\Models\Like::where('UserID', session('Data Login')->UserID)->where('FotoID', $item->FotoID)->first();
                        $warna = $cek ? 'red' : 'black'; // Ubah warna menjadi merah jika tombol like sudah diklik
                        ?>

                        <button type="submit" class="like-button button-spacing" style="color:<?php echo e($warna); ?>"><i class="far fa-thumbs-up"></i> Like <span class="like-count"><?php echo e(\App\Models\Like::where('FotoID', $item->FotoID)->count()); ?></span></button>
                    </form>

                    <a href="/komentar/<?php echo e($item->FotoID); ?>" class="comment-button button-spacing"><i class="far fa-comment"></i> Komentar</a>
                    <a href="/lihatkomentar/<?php echo e($item->FotoID); ?>" class="view-comment-button button-spacing"><i class="far fa-comment"></i> (<?php echo e(\App\Models\Komentar::where('FotoID', $item->FotoID)->count()); ?>)</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>
</body>
</html>
<?php /**PATH C:\laragon\www\galeri_bunga\resources\views/halamanutama.blade.php ENDPATH**/ ?>