<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Album</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    body {
      margin: 0;
      padding: 0;
      background: url('asset/images/jls.jpg') no-repeat;
      height: 100vh;
      background-size: cover;
      background-position: center;
      overflow: hidden;
    }

    header {
      background-color: #ff99cc;
      color: #fff;
      padding: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .album-section {
      padding: 20px;
      text-align: center;
    }

    .album-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
    }

    .album-box {
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin: 20px;
      width: 270px; /* Mengatur lebar tetap untuk setiap kotak album */
    }

    .album-box a {
      text-decoration: none; /* Menghilangkan garis bawah pada tautan di dalam .album-box */
    }

    .album-box img {
      width: 95%;
      border-radius: 8px;
      margin-bottom: 10px;
    }

    .album-title {
      font-size: 18px;
      margin-bottom: 10px;
    }

    .form-container {
      display: none;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      padding: 20px;
      max-width: 300px;
      margin: 20px;
    }

    .album-box:hover {
      cursor: pointer;
      border: 2px solid #ff9999;
    }

    .album-button {
      background: #cc3399;
      color: #fff;
      padding: 8px 16px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
      transition: background-color 0.3s ease;
      text-decoration: none;
    }

    .album-button:hover {
      background: #00ffff;
    }

    .back-button {
      background-color: #cc3399;
      color: #fff;
      padding: 8px 16px; /* Mengubah padding */
      border-radius: 5px; /* Mengubah border-radius */
      text-decoration: none;
      transition: background-color 0.3s ease;
      font-family: 'Montserrat'; /* Menggunakan font Montserrat */
      font-weight: bold;
      font-size: 14px;
      display: flex; /* Menjadikan tampilan tombol flex */
      align-items: center; /* Posisikan ikon dan teks ke tengah tombol */
    }

    .back-button:hover {
      background-color: #00ffff; /* Mengubah warna background saat dihover */
    }

    .back-button i {
      margin-right: 5px; /* Spasi antara ikon dan teks */
    }

  </style>
</head>

<body>
    <header>
        <a href="/halamanutama" class="back-button"><i class="fas fa-arrow-left"></i> Kembali</a>
    </header>
    <br>

<form action="/album" method="POST">
  <?php echo csrf_field(); ?>
  <div class="album-section">

    <div style="text-align: center; width: 100%;"> 
      <a href="/tambahalbum" class="album-button">Tambah Album</a>
    </div>

    <div class="album-container">
      <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(session()->get('Data Login')->UserID == $album->UserID): ?>
      <div class="album-box" onclick="showForm('Album 1')">
        <a href="foto/<?php echo e($album->AlbumID); ?>"><img src="<?php echo e(asset('asset/images/pp.jpg')); ?>" class="brand_logo" alt="Album Cover">
        <div class="album-title">Nama Album: <?php echo e($album->NamaAlbum); ?></div>
        <div class="album-title">Deskripsi: <?php echo e($album->Deskripsi); ?></div>
        <div class="album-title">Tanggal Dibuat: <?php echo e($album->TanggalDibuat); ?></div>
      </div>
      <div class="form-container" id="formContainer">
        <label for="photoUrl">URL Foto:</label>
        <input type="text" id="photoUrl" placeholder="Masukkan URL foto...">

        <label for="photoTitle">Judul Foto:</label>
        <input type="text" id="photoTitle" placeholder="Masukkan judul foto...">

        <button onclick="addPhoto()">Tambahkan Foto</button>
      </div>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</form>
</body>
</html>
<?php /**PATH C:\laragon\www\galeri_bunga\resources\views/album.blade.php ENDPATH**/ ?>