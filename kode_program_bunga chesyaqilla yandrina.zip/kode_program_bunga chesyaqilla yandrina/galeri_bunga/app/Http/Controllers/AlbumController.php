<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\LoginController;
use App\Models\Userr;
use App\Models\Album;

class AlbumController extends Controller
{

    public function album()
    {
       if(session('Data Login') != null) {
        $album = Album::all();
        return view('album', ['album' => $album]);
       }else {
        return redirect('/login')->with('pesanbaru', 'Silahkan Login Terlebih Dahulu !');
       }
    }

    public function tambahAlbum(Request $request)
    {
        $album = new Album();
        $album->NamaAlbum = $request->input('NamaAlbum');
        $album->Deskripsi = $request->input('Deskripsi');
        $album->TanggalDibuat = date('Y-m-d');
        $album->UserID = session('Data Login')->UserID;
        $album->save();

        return redirect('/album')->with('success','Album berhasil ditambahkan!');

    }
}
