<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Userr;
use App\Models\Foto;
use App\Models\Like;
use App\Models\Komentar;

class LikeController extends Controller
{
    public function like($FotoID)
    {
        $cek = Like::where('UserID', session('Data Login')->UserID)
                    ->where('FotoID', $FotoID)
                    ->first();

        if (!$cek) {
            $data = new Like();
            $data->FotoID = $FotoID;
            $data->UserID = session('Data Login')->UserID;
            $data->TanggalLike = date('Y-m-d');
            $data->save();
        } else {
            $cek->delete();
            return redirect()->back();
        }
    }

}

