<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Facades\Auth;
use App\Models\Komentar;
use App\Models\Userr;
use App\Models\Foto;

class KomentarController extends Controller
{
    public function tampilKomentar($FotoID)
    {
        if(session('Data Login') != null) {
        $komentar = Komentar::all();
        return view('komentar', compact('komentar', 'FotoID'));
    }else {
        return redirect('/login')->with('pesanbaru', 'Silahkan Login Terlebih Dahulu 1');
        }
    }

    public function lihatKomentar($FotoID)
    {
        if(session('Data Login') != null) {
            $komentar = Komentar::all();
            $user = Userr::all();
            return view('lihatkomentar', compact('komentar', 'user', 'FotoID'));
        }else {
            return redirect('/login')->with('pesanbaru', 'Siahkan Login Terlebih Dahulu !');
        }
    }

    public function aksiTambahKomentar(Request $request,$FotoID)
    {
        $data = new Komentar();
        $data -> IsiKomentar = $request->input('IsiKomentar');
        $data -> TanggalKomentar = date('Y-m-d');
        $data -> UserID = session ('Data Login')->UserID;
        $data -> FotoID = $FotoID;
        $data -> save();

        return redirect ('/halamanutama')->with('pesanbaru', 'Komentar berhasil dikirim !');
    }
}
