<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Userr;

class LoginController extends Controller
{
    public function tampil()
    {
        return view('login');
    }

    public function login(Request $request)
    {
        $request->validate([
        'Username' => 'required',
        'Password' => 'required',
    ]);

    $data = Userr::where('Username', $request->input('Username'))
                 ->where('Password', $request->input('Password'))
                 ->first();

                 if ($data === null) {
                     return redirect('/login')->with('pesan', 'Username / Password Salah !');
                    }else{
                        Session()->put('Data Login', $data);
            return redirect('/halamanutama');

    }
}

public function logout()
{
    session()->flush();
    return redirect('/home');
}

}
