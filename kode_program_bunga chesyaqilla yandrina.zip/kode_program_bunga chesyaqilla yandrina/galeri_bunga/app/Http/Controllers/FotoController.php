<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facedes\Auth;
use App\Models\Userr;
use App\Models\Album;
use App\Models\Foto;

class FotoController extends Controller
{
    public function foto($AlbumID)
    {
        if(session('Data Login') != null) {
            $album = Album::all();
            return view('tambahfoto', compact('album', 'AlbumID'));
    }else {
        return redirect('/login')->with('success', 'Album berhasil ditambahkan');
   }
    }

    public function lihatfoto($AlbumID)
    {
        if(session ('Data Login') != null) {
            $foto = Foto::all();
            return view('foto', compact('foto','AlbumID'));
       }else {
            return redirect('/login')->with('success', 'Album berhasil ditambahkan');
       }
    }

    public function lihatfoto1()
    {
        if(session ('Data Login') != null){
        $foto = Foto::all();
        return view('halamanutama', ['foto' => $foto]);
       }else{
        return redirect('/login')->with('success', 'Album berhasil ditambahkan');

       }
    }

    public function tambahFoto(Request $request,$AlbumID)
    {
        $filefoto =$request->file('foto');
        $filefoto->move('folder',$filefoto->getClientOriginalName());

        $data = new Foto();
        $data -> JudulFoto = $request->input('JudulFoto');
        $data -> DeskripsiFoto = $request->input('DeskripsiFoto');
        $data -> TanggalUnggah = date('Y-m-d');
        $data -> LokasiFile = '/folder/'.$filefoto->getClientOriginalName();
        $data -> UserID = session ('Data Login')->UserID;
        $data -> AlbumID = $AlbumID;
        $data -> save();

        Session()->flash('success', 'Foto Berhasil ditambahkan !');
        return redirect ('/album');
    }
}
