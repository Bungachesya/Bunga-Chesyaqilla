<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - Gallery Photo</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            background: url('asset/images/jls.jpg');
            height: 110vh;
            background-size: cover;
            background-position: center;
            overflow: hidden;
        }

        header {
            background-color: #ff99cc;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.5em;
            margin: 0;
            font-family: 'Pacifico';
        }

        nav {
            display: flex;
            align-items: center;
        }

        .loginBox {
            position: absolute;
            top: 55%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 400px;
            min-height: 200px;
            background: #ff99ff; /* Warna pink */
            border-radius: 10px;
            padding: 20px;
            box-sizing: border-box;
        }

        .user {
            margin: 0 auto;
            display: block;
            margin-bottom: 20px;
        }

        h3 {
            margin: 0;
            padding: 0 0 20px;
            color: #59238F;
            text-align: center;
        }

        .loginBox input {
            width: 100%;
            margin-bottom: 20px;
        }

        .loginBox input[type="text"],
        .loginBox input[type="password"] {
            border: none;
            border-bottom: 2px solid #262626;
            outline: none;
            height: 40px;
            color: #ffffff;
            background: transparent;
            font-size: 16px;
            padding-left: 20px;
            box-sizing: border-box;
        }

        .loginBox input[type="text"]:hover,
        .loginBox input[type="password"]:hover {
            color: #0b0c0c;
            border: 1px solid #42F3FA;
        }

        .loginBox input[type="submit"] {
            border: none;
            height: 40px;
            font-size: 15px;
            background: #59238F;
            color: #fff;
            border-radius: 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .loginBox input[type="submit"]:hover {
            background-color: #00ffff;
        }

        .register-link {
            color: #59238F;
            text-decoration: none;
            font-weight: bold;
            display: block;
            text-align: center;
            margin-top: 10px;
        }

        .register-link:hover {
            color: #00ffff;
        }

    </style>
</head>

<body>
    <form action="/login" method="POST">
        @csrf
    <header>
        <h1 class="logo" style="color: white">Gallery Photo</h1>
    </header>

    <div class="loginBox">
        <h3>REGISTRASI AKUN</h3>
        <form action="register.php" method="post">
            <div class="inputBox">
                <input id="uname" type="text" name="Username" placeholder="Username">
                <input id="pass" type="password" name="Password" placeholder="Password">
                <input id="mail" type="text" name="Email" placeholder="Email" required>
                <input id="unama" type="text" name="NamaLengkap" placeholder="Nama Lengkap" required>
                <input id="alamt" type="text" name="Alamat" placeholder="Alamat" required>
            </div>
            <input type="submit" name="" value="Registrasi">
        </form>
    </div>
</body>
</html>
