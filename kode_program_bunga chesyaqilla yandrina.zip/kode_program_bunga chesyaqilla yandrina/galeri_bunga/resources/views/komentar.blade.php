<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GALLERY PHOTO</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
            height: 110vh;
            background-size: cover;
            background-color: #ffccff
        }

        .navbar{
            background-color: #ff99cc;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.5em;
            margin: 0;
            font-family: 'Pacifico';
        }

        .comment-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .comment-form {
            width: 300px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .comment-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        .comment-form textarea {
            width: 100%;
            height: 100px;
            padding: 8px;
            margin-bottom: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            resize: vertical;
        }

        .comment-form button {
            width: auto;
            background-color: #ff99cc;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .comment-form button:hover {
            background-color: #f06292;
        }

        .back-button {
      background-color: #cc3399;
      color: #fff;
      padding: 8px 16px; /* Mengubah padding */
      border-radius: 5px; /* Mengubah border-radius */
      text-decoration: none;
      transition: background-color 0.3s ease;
      font-family: 'Montserrat'; /* Menggunakan font Montserrat */
      font-weight: bold;
      font-size: 14px;
      border: none; /* Menghapus border */
      cursor: pointer; /* Mengubah kursor saat dihover */
      display: flex; /* Menjadikan tampilan tombol flex */
      align-items: center; /* Posisikan ikon dan teks ke tengah tombol */
    }

    .back-button:hover {
      background-color: #00ffff; /* Mengubah warna background saat dihover */
    }

    .back-button i {
      margin-right: 5px; /* Spasi antara ikon dan teks */
    }

    </style>
</head>
<body>
    <nav class="navbar">
        <a href="/halamanutama" class="back-button"><i class="fas fa-arrow-left"></i> Kembali</a>
    </nav>

    <div class="comment-container">
        <form action="/lihatkomentar/{{ $FotoID }}" method="POST" class="comment-form">
            @csrf
            <label for="comment">Komentar:</label>
            <textarea id="comment" name="IsiKomentar" placeholder="Add your comment here"></textarea>
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
