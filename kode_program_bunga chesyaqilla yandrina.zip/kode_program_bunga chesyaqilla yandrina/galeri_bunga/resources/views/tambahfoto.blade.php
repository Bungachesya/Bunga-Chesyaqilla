<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Foto - Gallery Photo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            height: 100vh;
            background-size: cover;
            background-position: center;
            overflow: hidden;
            background-color: #ffccff;
        }

        header {
            background-color: #ff99cc;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.5em;
            margin: 0;
            font-family: 'Pacifico';
        }

        nav {
            display: flex;
            align-items: center;
        }

        nav a {
            text-decoration: none;
            color: rgb(255, 255, 255);
            margin: 0 15px;
            font-weight: bold;
        }

        .add-photo-form {
            position: absolute;
            top: 55%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 400px;
            background: #ff99cc;
            border-radius: 10px;
            padding: 20px;
            box-sizing: border-box;
            text-align: center;

        }

        .add-photo-form label {
            display: block;
            text-align: left;
            font-family: 'Times New Roman', Times, serif;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .add-photo-form input,
        .add-photo-form textarea {
            width: 100%;
            margin-bottom: 20px;
            padding: 10px;
            box-sizing: border-box;
            font-family: 'Times New Roman', Times, serif;
            font-size: 14px;
        }

        .add-photo-form input[type="file"] {
            padding: 5px;
        }

        .add-photo-form input[type="submit"] {
            border: none;
            outline: none;
            height: 30px;
            font-size: 12px;
            background: #59238F;
            color: #fff;
            border-radius: 20px;
            cursor: pointer;
        }

        .back-button {
      background-color: #cc3399;
      color: #fff;
      padding: 8px 16px; /* Mengubah padding */
      border-radius: 5px; /* Mengubah border-radius */
      text-decoration: none;
      transition: background-color 0.3s ease;
      font-family: 'Montserrat'; /* Menggunakan font Montserrat */
      font-weight: bold;
      font-size: 14px;
      border: none; /* Menghapus border */
      cursor: pointer; /* Mengubah kursor saat dihover */
      display: flex; /* Menjadikan tampilan tombol flex */
      align-items: center; /* Posisikan ikon dan teks ke tengah tombol */
    }

        .back-button:hover {
            background: #00ffff;
        }

        .back-button i {
            margin-right: 5px; /* Spasi antara ikon dan teks */
        }
    </style>
</head>

<body>
    <header>
        <a href="/album" class="back-button"><i class="fas fa-arrow-left"></i> Kembali</a>
    </header>

    <div class="add-photo-form">
        <h3 style="font-family: 'Times New Roman', Times, serif; font-size: 22px;">TAMBAH FOTO</h3>
        <form action="/foto/{{ $AlbumID }}" method="post" enctype="multipart/form-data">
            @csrf
            <label for="judul">Judul Foto:</label>
            <input type="text" id="judul" name="JudulFoto" required>

            <label for="deskripsi">Deskripsi Foto:</label>
            <textarea id="deskripsi" name="DeskripsiFoto" rows="4" required></textarea>

            <label for="file">Pilih Foto:</label>
            <input type="file" id="file" name="foto" accept="image/*" required>

            <input type="submit" name="" value="SUBMIT">
        </form>
    </div>
</body>
</html>
