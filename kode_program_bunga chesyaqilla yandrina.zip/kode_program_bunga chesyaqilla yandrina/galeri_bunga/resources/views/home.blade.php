<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Gallery Photo</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: url('asset/images/welcomee.jpg');
            height: 100vh;
            background-size: cover;
            background-position: center;
        }

        header {
            background-color: #ff99cc;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* logo gallery photo */
        .logo {
            font-size: 1.5em;
            margin: 0;
            font-family: 'Pacifico';
        }

        nav a {
            text-decoration: none;
            color: white;
            margin: 0 15px;
            font-weight: bold;
        }

        .login-button {
            background: #59238F;
            padding: 8px 16px;
            border-radius: 20px;
        }

        .login-button:hover {
            background: #00ffff;
        }

    </style>
</head>

<body>
    <header>
        <h1 class="logo" style="color: white">Gallery Photo</h1>
        <nav>
            <a href="login" class="login-button">Login</a>
            <a href="daftar" class="login-button">Registrasi</a>
        </nav>
    </header>
</body>
</html>
