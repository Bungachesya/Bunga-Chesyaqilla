<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Gallery Photo</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            background: url('asset/images/jls.jpg');
            height: 110vh;
            background-size: cover;
            background-position: center;
            overflow: hidden;
        }

        header {
            background-color: #ff99cc;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.5em;
            margin: 0;
            font-family: 'Pacifico';
        }

        nav {
            display: flex;
            align-items: center;
        }

        .loginBox {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 350px;
            min-height: 200px;
            background: #ff99ff; /* Warna pink */
            border-radius: 10px;
            padding: 50px;
            box-sizing: border-box;
        }

        .user {
            margin: 0 auto;
            display: block;
            margin-bottom: 20px;
        }

        h3 {
            margin: 0;
            padding: 0 0 20px;
            color: #59238F;
            text-align: center;
        }

        .loginBox input {
            width: 100%;
            margin-bottom: 20px;
        }

        .loginBox input[type="text"],
        .loginBox input[type="password"] {
            border: none;
            border-bottom: 2px solid #262626;
            outline: none;
            height: 40px;
            background: transparent;
            font-size: 16px;
            padding-left: 20px;
            box-sizing: border-box;
        }

        .loginBox input[type="text"]:hover,
        .loginBox input[type="password"]:hover {
            color: #0e0f0f;
            border: 1px solid #42F3FA;
        }

        .loginBox input[type="submit"] {
            border: none;
            outline: none;
            height: 40px;
            font-size: 15px;
            background: #59238F;
            color: #fff;
            border-radius: 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .loginBox input[type="submit"]:hover {
            background-color: #00ffff;
        }


        /* Tautan Daftar */
        .register-link-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
        }

        .register-text {
            color: #000;
            text-decoration: none;
            font-weight: bold;
            font-family: 'Times New Roman', sans-serif;
            margin-right: 4px;
        }

        .register-link {
            color: #59238F;
            text-decoration: none;
            font-weight: bold;
            font-family: 'Times New Roman', Times, serif;
        }

        .register-link:hover {
            color: #00ffff;
        }

        /* Pesan Notifikasi */
        .notification {
            position: fixed;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            background:#59238F;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
            margin-top: 20px;
            display: none;
            z-index: 999;
            width: 200px;
            text-align: center;
            animation: slideDown 0.5s ease forwards;
        }

        @keyframes slideDown {
            0% {
                top: -50px;
            }
            100% {
                top: 0;
            }
        }

    </style>
</head>

<body>
    <form action="/halamanutama" method="POST" id="loginForm">
        @csrf
    <header>
        <h1 class="logo" style="color: white">Gallery Photo</h1>
    </header>

    <div class="loginBox">
        <h3>LOGIN HERE !</h3>
            <div class="inputBox">
                <input id="uname" type="text" name="Username" placeholder="Username">
                <input id="pass" type="password" name="Password" placeholder="Password">
            </div>
            <input type="submit" name="" value="Login">
        </form>
        <div class="register-link-container">
            <span class="register-text">Belum punya akun?</span>
            <a href="daftar" class="register-link">Registrasi</a>
        </div>
    </div>

    <!-- Notifikasi -->
    <div class="notification" id="notification">Anda Berhasil Login!</div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Mencegah formulir dikirim

            // Menampilkan notifikasi
            document.getElementById('notification').style.display = 'block';

            // Menunda penampilan notifikasi selama 1 detik
            setTimeout(function() {
                document.getElementById('notification').style.display = 'none';
                // Mengirim formulir setelah penundaan
                event.target.submit();
            }, 1000);
        });
    </script>
</body>

</html>
